---
output:
  html_document: default
  pdf_document: default
---
# ejscreenapi

## **Basic user interface for obtaining EJScreen batch results (environmental and demographic conditions near multiple sites)**

This [R Shiny](https://shiny.rstudio.com/) app provides a very basic user interface that lets a user specify a radius in miles for circular buffering, and then upload a csv file of point locations, with a column each for lat and lon in decimal degrees, and it draws a very simple map of circular buffers at those points. It then can request from [EPA](https://epa.gov)'s server an [EJScreen](https://www.epa.gov/ejscreen) standard report on each buffer. The site-specific results, obtained one at a time (slowly) via an EJScreen API, are compiled into a single table, one row per buffered point, with all the indicator values as columns. Any extra columns uploaded along with lat and lon are included as the first set of columns in the results table. The results table can be sorted by a column, or searched (e.g., by state or facility name). The full table can be downloaded as a csv file that can be opened as a spreadsheet. This is intended as a very basic, slow interim tool for batches of EJScreen reports, while the new Environmental Justice Analysis Multisite (EJAM) tool is developed.

## **Important caveat**

These site-by-site results in many cases cannot be summarized accurately as overall statistics on the population overall or average person! For some analyses and some of the indicators, these results are sufficient for creating a summary overall. However, for some indicators - and for all indicators whenever buffers overlap - one can only roughly approximate the overall results using population-weighted means, and correctly calculating them is not possible with the information provided by the EJScreen API as of early 2022, which is what this simple tool provides access to. This is true for at least three reasons:

1.  The average site's percent over age 64 is not actually the same as the overall percent over age 64 among all people near any of the sites - That is because population density varies between sites, and a fixed radius circular buffer includes many people at some sites and very few at other sites.

2.  One might think that could be solved by using a population-weighted mean of scores at the various sites, but that only works if the denominator is total population. That means it works for percent over 64 but not for percent low-income, percent less than high school, percent pre 1960, or percent linguistic isolation, because those all use different kinds of denominators, such as the count of households or the count of people aged 25 and up. To correctly calculate percent low-income one needs the sum of counts of low-income divided by the sum of counts of people for whom the poverty income ratio was determined. Those counts, however, are not provided by the EJScreen API, so the overall summary results cannot be correctly calculated from the site-by-site reports.

3.  Even if the counts were available, circular buffers can overlap, and the site by site reports do not provide information about which residents are in overlapping buffers. This means double-counting cannot be avoided if buffers overlap. Even the correct total population count of unique residents near the set of sites is not necessarily available (the sum of that column would be an overcount). The other indicators would face the same issue.
