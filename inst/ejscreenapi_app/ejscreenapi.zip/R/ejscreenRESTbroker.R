#' Use EJScreen API for one circular buffer, get raw json or report output
#' 
#' See \url{'https://www.epa.gov/ejscreen/ejscreen-api'}
#'   and \link{ejscreenapi}
#' @details  Note the 
#'  # # public IP is 204.47.252.51 and internal is different. 
#'  
#' @param lon a longitude 
#' @param lat a latitude
#' @param distance radius of the circular buffer 
#' @param unit 9035 for miles, 9036 for kilometers
#' @param wkid spatial reference
#' @param f pjson for JSON, report for pdf report
#' @param url URL base for API
#' 
#' @examples \dontrun{
#'   browseURL(ejscreenRESTbroker(lon = -80, lat = 42, f = 'report'))
#'   x = (ejscreenRESTbroker(lon = -80, lat = 42))
#'   names(jsonlite::fromJSON(rawToChar(x$content)))
#'   }
#'
ejscreenRESTbroker <- function(lon, lat, url='https://ejscreen.epa.gov/mapper/ejscreenRESTbroker.aspx?namestr=', wkid=4326, distance=1, unit=9035, f='pjson') {
  
  # The public fixed IP is 204.47.252.51 
  # An app published to the early version of RStudio Connect server cannot resolve ejscreen.epa.gov properly, 
  # since it tries to resolve ejscreen.epa.gov to the internal IP but RStudio Connect Staging server cannot reach that. 
  # url='https://204.47.252.51/mapper/ejscreenRESTbroker.aspx?namestr='
  # Eventually this should work, and it does work if shiny app is launched locally rather than using version on staging server:
   url='https://ejscreen.epa.gov/mapper/ejscreenRESTbroker.aspx?namestr='
  
   if (any(NROW(lon) > 1, NROW(lat) > 1, NROW(distance) > 1 )) {stop('input must be only one point with one distance')}
  
  # MAY WANT TO SPLIT THIS OUT AS A FUNCTION, TO MAKE IT EASIER TO GET JSON AND ALSO APPEND THE PDF URL TO THAT
  this_request <-  paste0(url,
                          '&geometry={"spatialReference":{"wkid":',wkid,'},',
                          '"x":', lon, ',"y":', lat, '}',
                          '&distance=', distance,
                          '&unit=', unit, 
                          '&areatype=',
                          '&areaid=',
                          '&f=', f
  )
  # geometry <- paste0('{"spatialReference":{"wkid":',wkid, '},','"x":', lon, ',"y":', lat, '}')
  # url <- urltools::param_set(url, key = "geometry", value = geometry)
  # url <- urltools::param_set(url, key = "distance", value = distance)
  # url <- urltools::param_set(url, key = "unit", value = unit)
  # url <- urltools::param_set(url, key = "f",    value = f)
  
  if (f == 'report') {
    PDFURL <- gsub('ejscreenRESTbroker', 'EJSCREEN_report', this_request)
    # https://ejscreen.epa.gov/mapper/EJSCREEN_report.aspx?namestr=&geometry={"spatialReference":{"wkid":4326},"x":-88.14039550781403,"y":40.06610618160108}&distance=1&unit=9036&areatype=&areaid=&f=report 
    return(PDFURL) # returns the URL
  } else {
    # print(this_request)
    return( httr::GET(this_request))
    # return( httr::GET(this_request)$content)
  }
  
  # example that works:
  # httr::GET(
  #    paste0('https://ejscreen.epa.gov/mapper/ejscreenRESTbroker.aspx?namestr=&',
  #                  'geometry={"spatialReference":{"wkid":4326},"x":',
  #                  -80, ',"y":',42,
  #                  '}&distance=', 1,'&unit=9035&areatype=&areaid=&f=pjson')
  # )
  ### https://ejscreen.epa.gov/mapper/ejscreenRESTbroker.aspx?namestr=&geometry={"spatialReference":{"wkid":4326},"x":-80,"y":42}&distance=1&unit=9035&areatype=&areaid=&f=pjson 
}
