################################ Specify defaults, parameters for app ####

apptitle <- "EJScreen interim circular buffer batch tool"
maxpts <- 320
maxradius <- 5  # for slider input where user specifies radius
minradius <- 0.5
stepradius <- 0.5 
perhourslow <- 3000  # to give an estimate of how long it will take
perhourguess <- 6000 # seeing 8k if 1 mile, 4.7k if 5 miles, roughly. 207 ECHO run was 2.1 minutes, 5.9k/hr.
perhourfast <- 12000
meters_per_mile <- 1609.34
# to show some sample points at app startup:
default_points_shown_at_startup <- structure(
  list(siteid = c(1, 2), 
       sitename = c("example site 1", "example site 2"), 
       lon = c(-91.132107, -91.09), lat = c(30.494982, 30.45)), 
  row.names = c(NA, -2L), class = "data.frame")
echo_url <-  'https://echo.epa.gov/facilities/facility-search'
echo_message <- paste0('To use the ECHO website to search for and specify a list of regulated facilities, 
                       1) go to ', echo_url, ' and 2) under Facility Characteristics Results View select data table, 
                       click Search, then 3) click Customize Columns, use checkboxes to include Latitude and Longitude, 
                       then 4) click Download Data, then 5) return to this app to upload that ECHO site list.\n')
 # enableBookmarking(store = "url")

################################ Get packages, functions #### 

library(shiny)
library(DT) # used in ui.R and in server.R for displaying tabular data
# library(htmltools) # probably not needed... imported by shiny? provides tags like h5() etc
library(readr) # used in server.R
require(leaflet) # ; require(mapview) # for mapping. leaflet is used in ui.R and in ejscreenapi.R
# require(sf)
require(data.table) # used in ejscreenapi1.R, ejscreenapi.R
require(jsonlite)  # mostly for using API 
require(magrittr) # for the pipe used with leaflet in server.R,   %>%  
require(httr) # used by ejscreenRESTbroker() for httr::GET()
library(htmltools) # probably not needed... imported by shiny? provides tags like h5() etc
# library(urltools) # probably want to switch to using this nice package for working with URL-encoded parameters, encoding, parsing, etc. URLs


# These are in R folder so they get sourced just by running the app
# for (i in 1:length(list.files('./R/'))) {source(file = paste('./R/', list.files('./R/')[i],sep = ''))}

# ------------------------ Notes ------------------------ 
#
## To use test data  ####
#   See the inst folder within the ejscreenapi downloaded code/app
# 
## To create test data  ####
#   n=101
#   x <- cbind(siteid=1:n, sitename=paste('site', n), proxistat::testpoints_bg20(n))
#   write.csv(x, file = paste0('testpoints_',n,'.csv'), row.names = FALSE)
# 
##  To run the app that is on github ####
#    using R without having to separately download/install anything: (but it may be a private repo)
#  runUrl('https://github.com/ejanalysis/ejscreenapi/archive/master.tar.gz')
#
## To run the app if already downloaded/ cloned ####
#   shinyApp(ui = ui, server = server)

# ------------------ Help / documentation ------------------------ 

### Shiny, hosting ####
# 
# https://mastering-shiny.org/scaling-packaging.html
# Hosting shiny apps 
# https://docs.rstudio.com/shinyapps.io/index.html
# rsconnect::deployApp() # to deploy the app
# browseURL('https://ejanalysis.shinyapps.io/ejscreenapi/')
# 
### EJScreen API ####
# 
# browseURL(https://www.epa.gov/ejscreen/ejscreen-api)
# https://ejscreen.epa.gov/mapper/EJAPIinstructions.pdf
#  public access and internal IPs differ, it seems, and 
#  this shiny app on RStudio Connect server staging vs production version of app may have differing ability to resolve via DNS and reach different IPs 
#
### Server-related ####
#
# https://shiny.rstudio.com/articles/upload.html #https://mastering-shiny.org/action-transfer.html
# https://shiny.rstudio.com/articles/action-buttons.html
# https://shiny.rstudio.com/articles/modal-dialogs.html
# https://shiny.rstudio.com/articles/datatables.html
# https://shiny.rstudio.com/articles/download.html
# 
### UI-related (data tables and layouts etc.) ####
# 
# https://shiny.rstudio.com/articles/datatables.html
# https://shiny.rstudio.com/articles/layout-guide.html
# https://shiny.rstudio.com/articles/#user-interface
# https://shiny.rstudio.com/articles/download.html
#
# # notes on datatable options to use: hover, compact, order-columns, stripe?
# note that user can click a column name to sort on that column, then shift click on 2d column to sort on the 2d one within each unique value of the 1st column 

### Maps ####
# 
# https://rstudio.github.io/leaflet/shiny.html  
# https://towardsdatascience.com/create-interactive-map-applications-in-r-and-r-shiny-for-exploring-geospatial-data-96b0f9692f0f
# https://walker-data.com/census-r/mapping-census-data-with-r.html#interactive-mapping-with-leaflet
# https://rdrr.io/cran/mapview/
# https://github.com/r-spatial/mapview
# Census data and maps
# http://walker-data.com/umich-workshop/census-data-in-r/slides/#9  
# 
############################## #
