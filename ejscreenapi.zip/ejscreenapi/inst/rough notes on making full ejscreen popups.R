
ejscreen::make.popup.d(d = out[,names.d]/100, pctile = out[,names.d.pctile])

# one popup per site:

make.popups <- function(id, name, radius, lat, lon, pop, d, dpctile, e, epctile, ej, ejpctile, link, linktext='View Report') {
  linkify <- function(url, text) {
    paste0('<a href=\"', URLencode(url), '\", target=\"_blank\">', text, '</a>')
  }
  
  paste(
  'Site id', id, '<br>',
  'Area within ', radius, ' miles of ',  '<br>',
  'lat: ', lat, ', lon: ', lon,  '<br>',
  'Population: ', pop, '<br>',
  
  
  out$pctlowinc, '% low-income', '<br>',
  out$pctmin,    '% people of color', '<br>',
  
  linkify(link, linktext),
  sep = '')
  
}

paste( paste(1:10, '<br>') , paste(101:111, '<br>') ) 
paste(dvars, dpctiles)

out
o2=out[,1:20]




paste(  out$pctlowinc, '% low-income', '<br>',
        out$pctmin,    '% people of color', '<br>')
