################################################### #
# non-shiny example script 
################################################### #


################################################### #
# SET UP - CONSTANTS AND FUNCTIONS AND PACKAGES ####
if (1==0) { # in case put in R folder, avoid source() this script itself
  source('./global.R')
  for (i in 1:length(list.files('./R/'))) {source(file = paste('./R/', list.files('./R/')[i],sep = ''))}
  
  ################################################### #
  # UPLOAD POINTS OR USE AN EXAMPLE ####
  # p2 = read.csv('./inst/testpoints_05.csv')
  p2 = data.frame(
    siteid=1:2,
    sitename = c("example site A","example site B"), 
    longitude = c(-91.132107, -91.09), 
    latitude  = c(30.494982, 30.45)  
  )
  # SPECIFY RADIUS ####
  myradius = 0.5
  
  # MAP BEFORE BUFFERING 
  leaflet(p2) %>% addTiles() %>% addCircles(radius = myradius * 1700, popup = ~paste(1:nrow(p2)))
  
  ################################################### #
  # GET BUFFER RESULTS ####
  
  batchtableout <- ejscreenapi(lon = p2$lon, lat=p2$lat, radius = myradius)
  out <- batchtableout  #dim(out) # [1]   2 194
  oldnames <- names(out)
  names(out) <- fixnames(oldnames)
  # view 1 record in console
  t(out[1,-grep('pdfurl',names(out))])
  
  # Add clickable links #### 
  # to reports for popups and in table
  linkify <- function(url, text) {
    paste0('<a href=\"', URLencode(url), '\", target=\"_blank\">', text, '</a>')
  }
  pdflink <- linkify(out$pdfurl, 'View Report')
  out <- data.frame(URL=pdflink, out, stringsAsFactors = F, row.names = FALSE)
  
  ################################################### #
  # View Results in Map ####
  
  mypopup = paste(
    'Site #', 1:nrow(out), '<br>',
    'Area within ', out$radius.miles[1], ' miles of ',  '<br>',
    'lat: ', out$lat, ', lon: ', out$lon,  '<br>',
    'Population: ', out$pop, '<br>',
    out$pctlowinc, '% low-income', '<br>',
    out$pctmin,    '% people of color', '<br>',
    linkify(out$pdfurl, 'View Report'),
    sep = '')
  leaflet(p2) %>% addTiles() %>% clearShapes() %>%
    addCircles(radius = myradius * meters_per_mile, popup = mypopup)
  
  ################################################### #
  # VIEW INTERACTIVE TABLE OF RESULTS
  datatable(out,escape = F)
  
  ################################################### #
  # SAVE as csv OR EXCEL SPREADSHEET
  write.csv(data.frame(p2, out), row.names = FALSE, file = 'testoutput1.csv')
  excelhyperlinks <- paste0('=HYPERLINK("',URLencode(out$pdfurl) ,'","View Report")') # unclear how to force them to evaluate to show as links - can just hit F2 Enter in each Excel cell in that column to fix it, e.g.
  openxlsx::write.xlsx(cbind(link=excelhyperlinks, out), file = 'testout.xlsx')
  ################################################### #
}