################################ Specify defaults, parameters for app ####

apptitle <- "EJScreen interim circular buffer batch tool"
maxpts <- 250
maxradius <- 5  # for slider input where user specifies radius
minradius <- 0.5
stepradius <- 0.5 
perhourslow <- 3000  # to give an estimate of how long it will take
perhourguess <- 6000 # seeing 8k if 1 mile, 4.7k if 5 miles, roughly
perhourfast <- 12000
meters_per_mile <- 1609.34
# to show some sample points at app startup:
default_points_shown_at_startup <- structure(
  list(siteid = c(1, 2), 
       sitename = c("example site 1", "example site 2"), 
       lon = c(-91.132107, -91.09), lat = c(30.494982, 30.45)), 
  row.names = c(NA, -2L), class = "data.frame")
echo_url <-  'https://echo.epa.gov/facilities/facility-search'
echo_message <- paste0('To use the ECHO website to search for and specify a list of regulated facilities, 
                       go to ', echo_url, ' and under Facility Characteristics Results View select data table, 
                       click Search, then click Customize Columns, use checkboxes to include Latitude and Longitude, 
                       then click Download Data, then return to this app to upload that ECHO site list.')

################################ Get packages, functions #### 
library(shiny)
# library(htmltools) # probably not needed... imported by shiny? provides tags like h5() etc

require(sf);require(leaflet) # ; require(mapview) # for mapping
require(httr)
require(data.table); require(jsonlite)  # mostly for using API 
require(magrittr) # for the pipe used with leaflet,   %>%  

# These are in R folder so they get sourced just by running the app
# source('./R/ejscreenapiFORSHINY.R')
# # source('./R/prep.ejscreenapi.for.summarizerFORSHINY.R') # not used right now
# source('./R/makenumericdfFORSHINY.R')
# source('./R/speedmessage.R')

# ------------------------ Notes ------------------------ 
#
## To create test data  ####
#   n=101
#   x <- cbind(siteid=1:n, sitename=paste('site', n), proxistat::testpoints_bg20(n))
#   write.csv(x, file = paste0('testpoints_',n,'.csv'), row.names = FALSE)
# 
##  To run the app that is on github ####
#    using R without having to separately download/install anything:
#  runUrl('https://github.com/ejanalysis/ejscreenapi/archive/master.tar.gz')
#
## To run the app if already downloaded/ cloned ####
#   shinyApp(ui = ui, server = server)

# ------------------ Help / documentation ------------------------ 

### Shiny, hosting ####
# 
# https://mastering-shiny.org/scaling-packaging.html
# Hosting shiny apps 
# https://docs.rstudio.com/shinyapps.io/index.html
# rsconnect::deployApp() # to deploy the app
# browseURL('https://ejanalysis.shinyapps.io/ejscreenapi/')
# 
### EJScreen API ####
# 
# browseURL(https://www.epa.gov/ejscreen/ejscreen-api)
# https://ejscreen.epa.gov/mapper/EJAPIinstructions.pdf
# 
### Server-related ####
#
# https://shiny.rstudio.com/articles/upload.html #https://mastering-shiny.org/action-transfer.html
# https://shiny.rstudio.com/articles/action-buttons.html
# https://shiny.rstudio.com/articles/modal-dialogs.html
# https://shiny.rstudio.com/articles/datatables.html
# https://shiny.rstudio.com/articles/download.html
# 
### UI-related (data tables and layouts etc.) ####
# 
# https://shiny.rstudio.com/articles/datatables.html
# https://shiny.rstudio.com/articles/layout-guide.html
# https://shiny.rstudio.com/articles/#user-interface
# https://shiny.rstudio.com/articles/download.html
#
# # notes on datatable options to use: hover, compact, order-columns, stripe?
# note that user can click a column name to sort on that column, then shift click on 2d column to sort on the 2d one within each unique value of the 1st column 

### Maps ####
# 
# https://rstudio.github.io/leaflet/shiny.html  
# https://towardsdatascience.com/create-interactive-map-applications-in-r-and-r-shiny-for-exploring-geospatial-data-96b0f9692f0f
# https://walker-data.com/census-r/mapping-census-data-with-r.html#interactive-mapping-with-leaflet
# https://rdrr.io/cran/mapview/
# https://github.com/r-spatial/mapview
# Census data and maps
# http://walker-data.com/umich-workshop/census-data-in-r/slides/#9  
# 
############################## #
