library(shiny)

ui <- fluidPage(  
  titlePanel(apptitle),  # apptitle, minradius, maxradius, stepradius are defined in global.R
  fluidRow(
    column(
      4, 
      sliderInput("radius", "Miles radius:",
                  min = minradius, max = maxradius, value = 1, step = stepradius),
      shiny::actionButton('echobutton', label = 'Find sites via ECHO'),
      shiny::fileInput('pointsfile', 'Upload csv with column headers lat and lon',
                       accept = c("text/csv","text/comma-separated-values,text/plain",".csv")),
      shiny::textOutput('count'),  # how many uploaded
      shiny::textOutput('maxn'),    # how many allowed max
      shiny::actionButton('runbutton', label = 'Start'),
      h5('Click Start, then wait until table appears below'),  # h5 is via shiny via htmltools
      shiny::textOutput('speed'),   # estimated minutes needed
      shiny::downloadButton('downloadbutton', 'Download these results') 
    ),
    column(
      8,
      leaflet::leafletOutput('mapout')
    )
  ),
  fluidRow(
    column(
      12,
      # # May want to show uploaded input table before results are calculated?
      # conditionalPanel(
      #   condition = "TRUE", # condition = "isTRUE(show_input_table())", #   
      #   DT::dataTableOutput('rendered_input_table')
      #   # tags$div(id = 'ui_input_table', DT::dataTableOutput('rendered_input_table'))
      # ),
      conditionalPanel(
        condition = "TRUE", # condition = "isTRUE(show_results_table())", # 
        DT::dataTableOutput('rendered_results_table'),
      )
    )
  )
)


