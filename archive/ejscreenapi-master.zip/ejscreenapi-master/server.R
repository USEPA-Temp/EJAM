library(shiny)

server <- function(input, output) {
  
  ##################### Upload point locations csv file ####
  pts <- shiny::reactive({
    pts_filecontents <- readr::read_csv(file = input$pointsfile$datapath)
    if ('lat' %in% names(pts_filecontents) & 'lon' %in% names(pts_filecontents)) {
    } else {
      # if not uploaded yet, show default 2 point example. if uploaded with bad colnames, show popup error message
      if (0 == length(pts_filecontents)) { 
        pts_filecontents <- default_points_shown_at_startup  # defined in global.R
      } else {
        if ('FacLong' %in% names(pts_filecontents) & 'FacLat' %in% names(pts_filecontents)) {
          # for now, allow those 2 ECHO column names and just silently rename to be lat and lon
          names(pts_filecontents) <- gsub('FacLat', 'lat', names(pts_filecontents)); names(pts_filecontents) <- gsub('FacLong', 'lon', names(pts_filecontents)) # as used by leaflet, and so names are unique even when uploaded table is merged with EJScreen results
          # the variable names latitude and longitude are compatible with leaflet() but we will not rename them except for that one purpose right when mapping
        } else {
          showModal(modalDialog(title = "Error",paste0("csv file must have columns named lat and lon (the words lat and lon should be in the 1st row) ", ''), easyClose = TRUE))
          pts_filecontents <- default_points_shown_at_startup  # defined in global.R   This line is so default example is shown instead of uploaded file that does not have correct columns 
        }
      }
    }
    pts_filecontents
  })
  output$count <- renderText({paste0(NROW(pts()), ' points uploaded')})
  output$speed <- renderText({speedmessage(NROW(pts()), perhourslow = perhourslow, perhourfast = perhourfast, perhourguess = perhourguess)})  # speedmessage defined as function in R folder, default variables defined in global.R
  output$maxn  <- renderText({paste0(maxpts, ' points max. allowed')})   # maxpts defined in global.R
  
  output$rendered_input_table <- DT::renderDataTable({pts()})
  
  ##################### Get results via EJScreen API ####
  results_table <- bindEvent(reactive({
   # wait until click  # and could use  shiny::bindEvent(ignoreInit = TRUE, 
    results_table <- 0
    results_table <- isolate({   # isolate this to avoid refresh every time pts or radius changes
      if (length(pts()) != 0) {
        if (NROW(pts()) <= maxpts) {
          showModal(modalDialog(
            title="RESULTS TABLE LOADING - PLEASE WAIT...",
            speedmessage(NROW(pts()), perhourslow = perhourslow, perhourfast = perhourfast, perhourguess = perhourguess),
            # "Please wait for results to be downloaded into table before proceeding.",
            size="l",footer=NULL))
          batchtableout <- ejscreenapiFORSHINY(lon = pts()$lon, lat=pts()$lat, radius = input$radius)
          cbind(pts(), batchtableout)
        } else {
          showModal(modalDialog(title = "Warning",paste0("Maximum number of points allowed here is ", maxpts), easyClose = TRUE))
        }
      }})
    # results_table <- prep.ejscreenapi.for.summarizerFORSHINY(results_table)
    # would do a little more cleanup but require 2 more functions...fix.miles.field, fix.statename.field
    results_table
  }), input$runbutton)
  
  output$rendered_results_table <- DT::renderDataTable({results_table()})
  
  ##################### Remove popup window when results are ready ####
  observe({
    req(results_table())
    removeModal()
    # maybe remove UI here, to not show the input table anymore
  })
  
  ##################### show popup window about ECHO search ####
  bindEvent(observe({
    showModal(modalDialog(title = "Use ECHO facility search tools to specify list of sites", 
                          echo_message, easyClose = TRUE))
    browseURL(echo_url)
  }), input$echobutton )
  
  ##################### Hide inputs table when results are ready ####
  # MIGHT NEED TO USE 
  #   insertUI(selector = "#ui_input_table", ui = tags$div(id='ui_input_table', DT::dataTableOutput('rendered_input_table')))
  #   removeUI(selector = "div:has(> #ui_input_table)")
  # When Start/Get results button clicked, set show_input_table() to FALSE and show_results_table to TRUE
  # show_input_table   <- bindEvent(reactive({input$runbutton; FALSE}), input$runbutton) # , results_table())  # when click Start/Run to get results for those points, hide input columns since they are also in the results
  # show_results_table <- bindEvent(reactive({TRUE}),  input$runbutton) # , results_table())  # when click Start/Run to get results for those points
  
  ##################### Show inputs table always? or just when inputs exist- nonissue unless default example inputs are removed from app ####
  # When Browse/Upload button clicked, (or when input info is updated?) set show_input_table() to TRUE and MAYBE ALSO show_results_table to FALSE
  # show_input_table   <- bindEvent(reactive({TRUE}), pts()) # when upload new points to analyze
  # show_results_table <- bindEvent(reactive({FALSE}), pts()) # when upload new points to analyze, MAKE RESULTS DISAPPEAR?
  
  
  ##################### Download results ####
  # ideally could make this button only appear once there is a dataset uploaded
  output$downloadbutton <- shiny::downloadHandler(
    filename = 'output.csv', contentType = 'text/csv', 
    content = function(file) {
      if (0 == length(results_table())) { 
        showModal(modalDialog(title = "Warning", "Results are not created until Start is clicked", easyClose = TRUE))
      } else {
        if (NROW(pts()) != NROW(results_table())) {
          # this might mean they uploaded a new dataset and did not hit Start again. could check for that more specifically, but this is probably good enough for now. might happen if API fails to return some rows? or maybe ejscreenapi function fixed that so it always returns same number as submitted.
          showModal(modalDialog(title = "Warning", "Uploaded points and results table have different numbers of rows", easyClose = TRUE))
        }
        write.csv(results_table(), file, row.names = FALSE)
      }
    })
  
  ##################### Draw a Map ####
  output$mapout <- leaflet::renderLeaflet({
    mypoints <- pts()
    if (length(mypoints) != 0) {
      names(mypoints) <- gsub('lon','longitude', names(mypoints)); names(mypoints) <- gsub('lat','latitude', names(mypoints))
      isolate( # do not redraw entire map and zoom out and reset location viewed just because radius changed
        leaflet(mypoints) %>% addTiles() %>% addCircles(radius = input$radius * meters_per_mile) 
      )
    } else {
      leaflet() %>% addTiles() %>% setView(-110, 46, zoom = 3)
    }
    # projcrs <- "+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0" #  lat / lon
    # try({mapView(   (st_as_sf(x = (pts()), coords = c("lon", "lat"), crs = projcrs)))@map}, silent = TRUE)
  } )
  
  observe({
    mypoints <- pts()
    if (!('sitename' %in% names(mypoints))) {mypoints$sitename <- seq_len(NROW(mypoints))} # use row number if sitename column name not found
    if (length(mypoints) != 0) {
      leafletProxy("mapout", data = mypoints) %>%
        clearShapes() %>%
        addCircles(
          radius = input$radius * meters_per_mile,
          popup = ~paste(sitename)
        )
    }
  })
}
