#' Use EJScreen API to get stats on each circular buffer
#' 
#' Requests a standard EJScreen report for each of one or more circular buffers.
#' Specify a radius and vector of latitude longitude points,
#' and get for a buffer the population weighted mean value of each raw indicator
#' like percent low-income, and total population count, and percentiles for those
#' raw indicator scores, all from EJScreen, as in an EJScreen standard report. 
#' Note that this API is fairly slow, so it is fine for 10 sites, but not large numbers.
#' It does about 7k to 10k sites per hour, for circular buffers of 1 or 3 mile radius.
#' It sometimes crashes, with a JSON lexical error, 
#' which may be caused by unreliable results from the API
#' rather than the code requesting results via the API.
#' 
#' Uses valid_lat_lon(), 
#' 
#' @param lon Longitude numeric vector
#' @param lat Latitude numeric vector
#' @param radius radius of circular buffer - Probably in miles but should confirm
#' @param report_every_n Should it report ETA snd possibly save interim file after every n points
#' @param save_when_report optional, write .rdata file to working directory 
#'   with results so far, after ever n points, to have most results even if it crashes
#'
#' @export
#'
#' @examples  
#'  \dontrun{
#'  # Specify size of buffer circle and pick random points as example data
#'  myradius <- 3
#'  pts <- structure(list(lon = c(-96.4798957, -111.7674343, -75.4173589, 
#'  -95.9573172, -87.8402677, -77.9996191, -73.920702, -79.9545638, 
#'  -76.0638877, -114.9881473), lat = c(31.782716, 33.7522735, 39.8697972, 
#'  33.2522474, 41.9763992, 38.4661259, 41.2940801, 32.8099327, 40.9888266, 
#'  36.0043628), id = 1:10), row.names = c(NA, -10L), class = "data.frame")
#'  
#'   out <- ejscreenapi(pts$lon, lat=pts$lat, radius = myradius)
#'  
#'  t(out[1:2,]) 
#'  }
ejscreenapiFORSHINY <- function(lon, lat, radius=5, report_every_n=1000, save_when_report=FALSE) {

    valid_lat_lon <- function(lat, lon) {
    # TRUE only if both lat and lon seem valid
    if( any(badlat <- is.na(lat)) || any(badlon <- is.na(lon)) ) {
      bad <- is.na(lat) | is.na(lon)
    } else {
      bad <- rep(FALSE, length(lat))
    }
    bad <- bad | lat < -90 | lat > 90 | lon < -180 | lon > 180
    return(!bad)
  }
  
  
  finished_without_crashing <- FALSE
  outlist <- list()
  # outlist[!(sapply(outlist, is.null))]
  on.exit({if (!finished_without_crashing) save(outlist, file='saved_this_before_crash.rdata') })
  # example of an error code crashing a large batch run:
  #
  # Iteration #: 6479
  # Iteration #: 6480Error: lexical error: invalid char in json text.
  # <!DOCTYPE html>  <html>      <h
  # (right here) ------^
  #   In addition: Warning message:
  #   In batch.summarizer::ejscreenapi(x$lon, lat = x$lat, radius = radius,  :
  #                                      
  #                                      Error: lexical error: invalid char in json text.
  #                                    <!DOCTYPE html>  <html>      <h
  #                                    (right here) ------^ > View(x)
  
  
  # as of 2021 - note this excludes the geometry column
  outcolnames <-  c("RAW_E_PM25", "RAW_E_O3", "RAW_E_DIESEL", "RAW_E_CANCER", "RAW_E_RESP", 
                    "RAW_E_TRAFFIC", "RAW_E_LEAD", "RAW_E_NPL", "RAW_E_RMP", "RAW_E_TSDF", 
                    "RAW_E_NPDES", "RAW_D_INDEX", "RAW_D_MINOR", "RAW_D_INCOME", 
                    "RAW_D_LING", "RAW_D_LESSHS", "RAW_D_UNDER5", "RAW_D_OVER64", 
                    "S_E_PM25", "S_E_O3", "S_E_DIESEL", "S_E_CANCER", "S_E_RESP", 
                    "S_E_TRAFFIC", "S_E_LEAD", "S_E_NPL", "S_E_RMP", "S_E_TSDF", 
                    "S_E_NPDES", "S_D_INDEX", "S_D_MINOR", "S_D_INCOME", "S_D_LING", 
                    "S_D_LESSHS", "S_D_UNDER5", "S_D_OVER64", "S_P_PM25", "S_P_O3", 
                    "S_P_DIESEL", "S_P_CANCER", "S_P_RESP", "S_P_TRAFFIC", "S_P_LEAD", 
                    "S_P_NPL", "S_P_RMP", "S_P_TSDF", "S_P_NPDES", "S_E_PM25_PER", 
                    "S_E_O3_PER", "S_E_DIESEL_PER", "S_E_CANCER_PER", "S_E_RESP_PER", 
                    "S_E_TRAFFIC_PER", "S_E_LEAD_PER", "S_E_NPL_PER", "S_E_RMP_PER", 
                    "S_E_TSDF_PER", "S_E_NPDES_PER", "S_D_INDEX_PER", "S_D_MINOR_PER", 
                    "S_D_INCOME_PER", "S_D_LING_PER", "S_D_LESSHS_PER", "S_D_UNDER5_PER", 
                    "S_D_OVER64_PER", "R_E_PM25", "R_E_O3", "R_E_DIESEL", "R_E_CANCER", 
                    "R_E_RESP", "R_E_TRAFFIC", "R_E_LEAD", "R_E_NPL", "R_E_RMP", 
                    "R_E_TSDF", "R_E_NPDES", "R_D_INDEX", "R_D_MINOR", "R_D_INCOME", 
                    "R_D_LING", "R_D_LESSHS", "R_D_UNDER5", "R_D_OVER64", "R_P_PM25", 
                    "R_P_O3", "R_P_DIESEL", "R_P_CANCER", "R_P_RESP", "R_P_TRAFFIC", 
                    "R_P_LEAD", "R_P_NPL", "R_P_RMP", "R_P_TSDF", "R_P_NPDES", "R_E_PM25_PER", 
                    "R_E_O3_PER", "R_E_DIESEL_PER", "R_E_CANCER_PER", "R_E_RESP_PER", 
                    "R_E_TRAFFIC_PER", "R_E_LEAD_PER", "R_E_NPL_PER", "R_E_RMP_PER", 
                    "R_E_TSDF_PER", "R_E_NPDES_PER", "R_D_INDEX_PER", "R_D_MINOR_PER", 
                    "R_D_INCOME_PER", "R_D_LING_PER", "R_D_LESSHS_PER", "R_D_UNDER5_PER", 
                    "R_D_OVER64_PER", "N_E_PM25", "N_E_O3", "N_E_DIESEL", "N_E_CANCER", 
                    "N_E_RESP", "N_E_TRAFFIC", "N_E_LEAD", "N_E_NPL", "N_E_RMP", 
                    "N_E_TSDF", "N_E_NPDES", "N_D_INDEX", "N_D_MINOR", "N_D_INCOME", 
                    "N_D_LING", "N_D_LESSHS", "N_D_UNDER5", "N_D_OVER64", "N_P_PM25", 
                    "N_P_O3", "N_P_DIESEL", "N_P_CANCER", "N_P_RESP", "N_P_TRAFFIC", 
                    "N_P_LEAD", "N_P_NPL", "N_P_RMP", "N_P_TSDF", "N_P_NPDES", "N_E_PM25_PER", 
                    "N_E_O3_PER", "N_E_DIESEL_PER", "N_E_CANCER_PER", "N_E_RESP_PER", 
                    "N_E_TRAFFIC_PER", "N_E_LEAD_PER", "N_E_NPL_PER", "N_E_RMP_PER", 
                    "N_E_TSDF_PER", "N_E_NPDES_PER", "N_D_INDEX_PER", "N_D_MINOR_PER", 
                    "N_D_INCOME_PER", "N_D_LING_PER", "N_D_LESSHS_PER", "N_D_UNDER5_PER", 
                    "N_D_OVER64_PER", 
                    "stateAbbr", "stateName", "epaRegion", "totalPop", 
                    "NUM_NPL", "NUM_TSDF", "statLayerCount", "statLayerZeroPopCount", 
                    "weightLayerCount", "timeSeconds", "distance", "unit", "statlevel", 
                    "inputAreaMiles")
  
  # return an empty row when no valid results found for that point
  emptyresults <- data.frame(matrix(data = NA, nrow = 1, ncol = length(outcolnames))) 
  colnames(emptyresults) <- outcolnames
  
  benchmark.start <- Sys.time()  
  
  ok_point <- valid_lat_lon(lat, lon)
  if (!all(ok_point)) {
    warning(paste0(sum(!ok_point), ' lat lon values look invalid'))
    lat[!ok_point] <- NA
    lon[!ok_point] <- NA
    # rather than drop those rows, try to return NA values
  }
  
  pts <- data.frame(lon=lon, lat=lat)
  n <- NROW(pts)
  cat("\n")
  cat("Buffering for", n, 'points for radius of', radius, '\n')
  cat('\n')
  
  # pre-allocate space for results
  outlist <- vector(mode = 'list', length = n)
  noresults_count <- 0
  
  speedreport <- function(start,end,n) {
    # report time elapsed and avg speed
    benchmark.start <- start
    benchmark.end <- end
    total.benchmark <- difftime(benchmark.end, benchmark.start)
    total.seconds <- difftime(benchmark.end, benchmark.start, units = 'secs')
    perhour <- round((n/ as.numeric(total.seconds))*3600,0)
    cat('\n')
    cat(paste0(
      'Rate of ',
      format(round((n / as.numeric(total.seconds))*3600,0), big.mark=',', scientific=FALSE), 
      ' buffers per hour (',
      format(n,big.mark = ',', scientific = FALSE),
      ' lat/long pairs per ',
      format(round(as.numeric(total.seconds),0), big.mark = ',', scientific = FALSE),
      ' seconds)'
    )  )
    cat('\n')
    print(round(total.benchmark, 1))
    invisible(perhour)
  }
  
  ###########################  LOOP OVER POINTS 

    for (i in 1:dim(pts)[1]){
    cat(paste0('Iteration #: ', i))
    
      # Contact the EJScreen server using GET() and read results using fromJSON()
      # GET() is in the httr package but also in other packages
      # fromJSON() is in RJSONIO and  jsonlite  and  rjson
      
      ej.data <- httr::GET(
      paste0('https://ejscreen.epa.gov/mapper/ejscreenRESTbroker.aspx?namestr=&',
             'geometry={"spatialReference":{"wkid":4326},"x":',
             pts$lon[[i]], ',"y":', pts$lat[[i]],
             '}&distance=', radius,'&unit=9035&areatype=&areaid=&f=pjson')
      #    '}&distance=5&unit=9035&areatype=&areaid=&f=pjson')
    )$content
    
    ej.data <- try(data.table::as.data.table(jsonlite::fromJSON(rawToChar(ej.data))))
    
    # HANDLE ERROR IN JSON PARSING
    if  (any(class(ej.data) == 'try-error')) {
      warning('error in parsing JSON returned by API for point number ', i, ' - Returning no result for that point.')
      ej.data <- emptyresults
    }
    
    # HANDLE BLANK RESULTS THAT API RETURNS DUE TO SMALL BUFFER OR SPARSELY POPULATED AREA
    #
    # Note: api does not return values for coords in highly nonpopulated areas.
    # it just returns this as ej.data:
    #    message                                                messageType
    # 1: Input area too small or sparsely populated for output  underLimit
    #
    # lat lon are stored in a second and third row but the rest of those rows is just duplicated info so drop them
    # lon is in   ej.data[2,'geometry']  and also  is  pts$lon[i]
    # save all but geometry column if got valid results back, i.e. got more than 100 columns instead of an error message
    if (NCOL(ej.data) > 100){
      ej.data$geometry <- NULL 
      outlist[[i]] <- unique(ej.data) 
    } else {
      # assume got error message and save as a table full of NA values
      cat(' No results - (probably because) area too small or sparsely populated for output')
      outlist[[i]] <- emptyresults
      noresults_count <- noresults_count + 1
    }
    
    # SAVE THE LATITUDE AND LONGITUDE INFO AS COLUMNS
    outlist[[i]][,'lon'] <- pts$lon[i]
    outlist[[i]][,'lat'] <- pts$lat[i]
    
    # REPORT ON PROGRESS SO FAR IN LOOP 
    # AND SAVE INTERIM RESULTS IF NEEDED
    # report_every_n=1000, save_when_report=FALSE
    if (i %% report_every_n == 0 | (i > report_every_n & i == n)) {
      # this is end of a group of report_every_n points or is the last incomplete chunk assuming we had a big enough n to bother chunking at all
      chunknum <- ceiling(i/report_every_n)
      chunkstart <- ((chunknum - 1) * report_every_n) + 1  #( i + 1 - report_every_n)
      chunkend <- i
      if (save_when_report) {
        x <- outlist[chunkstart:chunkend]
        save(x, file = paste('temp_ejscreenapibatch_outlist_chunk', chunknum, '.rdata', sep = ''))
      }
      cat('---------------------\n')
      hourly <- speedreport(benchmark.start, Sys.time(), i)
      remaining <- n - i
      hrsleft <- remaining / hourly
      cat('Estimated', round(hrsleft * 60,0), 'minutes remaining \n')
      cat('Results were unavailable for', noresults_count,'out of these', n, 'sites. \n')
    } 
    cat('\n')
    # END OF LOOP
  } # end of loop over buffers
  
  # SAVE INTERIM RESULTS IF NEEDED
  if (n < report_every_n & save_when_report) {
    # we did not save any chunks, so save whole, in case rbind fails
    save(outlist, file='temp_ejscreenapibatch_outlist_full.rdata')
  }
  
  # Format results as a single data.table (like a data.frame)
  results <- data.table::rbindlist(outlist, fill = T, idcol = 'id')
  # results <- do.call(rbind, outlist) # if data.frame not data.table
  
  # Fix numeric columns that got turned into character format
  results <- makenumericdfFORSHINY(results)
  
  speedreport(benchmark.start,Sys.time(),n)  
  finished_without_crashing <- TRUE
  
  invisible(results)
}
