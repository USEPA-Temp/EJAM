#' Format EJScreen API batch results to upload to batch.summarizer
#'
#' This just fixes the distance and stateName variables
#' 
#' @param output_of_ejscreenapi Result of batch.summarizer::ejscreenapi()
#'
#' @export
#'
#' @examples
#'   # EXAMPLE OF USING EJScreen API outputs in batch.summarizer
#'   ## How to get batch results from EJScreen API, 
#'   ## prepare them for use in the batch.summarizer, save as csv file,
#'   ## and then be able to run the R Shiny app batch.summarizer 
#'   ## and use app to upload that csv, to get a summary of those batch results.
#'   ## 
#'   ## Specify size of buffer circle and pick random points as example data
#'   # myradius <- 1
#'   # n <- 10
#'   # pts <- proxistat::testpoints_block2010(n)
#'   
#'   ## RUN BATCH BUFFER USING EJScreen API
#'   # outlist <- batch.summarizer::ejscreenapi(pts$lon, lat=pts$lat, radius = myradius)
#'   # 
#'   # api.out.table <- prep.ejscreenapi.for.summarizer(outlist, lat = pts$lat, lon = pts$lon, radius = myradius)
#'   #
#'   ## SAVE FILE OF BATCH RESULTS FOR IMPORT TO SUMMARIZER
#'   # write.csv(api.out.table, file = '~/Downloads/api.out.table.csv')

prep.ejscreenapi.for.summarizerFORSHINY <- function(output_of_ejscreenapi) {
  output_of_ejscreenapi$distance  <- fix.miles.field(output_of_ejscreenapi$distance)
  output_of_ejscreenapi$stateName <- fix.statename.field(output_of_ejscreenapi$stateName)
  return(output_of_ejscreenapi)
}

