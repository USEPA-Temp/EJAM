ejscreenmaplink <- function(where) {
  # where can be 30.450000,-91.090000
  # https://ejscreen.epa.gov/mapper/index.html?wherestr=30.450000,-91.090000
  URLencode(paste0('https://ejscreen.epa.gov/mapper/index.html?wherestr=', where))
  }